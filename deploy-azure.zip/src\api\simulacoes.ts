/** Base URL da API (produção: ex. https://sua-api.azurewebsites.net). Em dev, Vite faz proxy de /api → servidor local. */
const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, '') ?? '';

let getIdToken: () => Promise<string | null> = async () => null;

/** Registrado pelo AuthContext após login (Bearer token na API). */
export function configureApiAuth(fn: () => Promise<string | null>) {
  getIdToken = fn;
}

async function authHeader(): Promise<Record<string, string>> {
  const token = await getIdToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function apiUrl(path: string) {
  if (path.startsWith('/')) return `${API_BASE}${path}`;
  return `${API_BASE}/${path}`;
}

function looksLikeHtml(text: string): boolean {
  const s = text.trim().slice(0, 40).toLowerCase();
  return s.startsWith('<!') || s.startsWith('<html') || s.startsWith('<head');
}

const API_UNAVAILABLE_HINT =
  'A API devolveu HTML em vez de JSON: o servidor Node (server.js) não está acessível neste endereço. ' +
  'Em desenvolvimento use npm run dev:all (ou dois terminais: npm run server e npm run dev). ' +
  'No Firebase Hosting, /api não existe — defina VITE_API_BASE no .env com a URL da API publicada (ex.: Azure App Service) e faça novo build.';

async function readErrorBody(r: Response): Promise<string> {
  const t = await r.text();
  if (looksLikeHtml(t)) return API_UNAVAILABLE_HINT;
  const trimmed = t.trim();
  if (trimmed.startsWith('{')) {
    try {
      const j = JSON.parse(trimmed) as { error?: string; message?: string };
      if (typeof j.error === 'string' && j.error) return j.error;
      if (typeof j.message === 'string' && j.message) return j.message;
    } catch {
      /* ignore */
    }
  }
  if (trimmed) return trimmed;
  const st = r.statusText?.trim();
  if (st) return `${st} (HTTP ${r.status})`;
  return `Erro HTTP ${r.status}`;
}

async function parseJsonResponse<T>(r: Response): Promise<T> {
  const text = await r.text();
  if (looksLikeHtml(text)) {
    throw new Error(API_UNAVAILABLE_HINT);
  }
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new Error(text.slice(0, 200) || 'Resposta não é JSON válido.');
  }
}

export interface SimulacaoListRow {
  id: number;
  nome_lote: string;
  dias_confinamento: number;
  peso_entrada_kg: number;
  gmd_projetado: number;
  cms_projetado: number;
  custo_diaria: number;
  data_simulacao: string;
  tem_params?: number;
}

export interface SimulacaoDetailRow extends SimulacaoListRow {
  params_json: string | null;
}

export async function listSimulacoes(): Promise<SimulacaoListRow[]> {
  const r = await fetch(apiUrl('/api/simulacoes'), { headers: await authHeader() });
  if (!r.ok) throw new Error(await readErrorBody(r));
  return parseJsonResponse<SimulacaoListRow[]>(r);
}

export async function getSimulacao(id: number): Promise<SimulacaoDetailRow> {
  const r = await fetch(apiUrl(`/api/simulacoes/${id}`), { headers: await authHeader() });
  if (!r.ok) throw new Error(await readErrorBody(r));
  return parseJsonResponse<SimulacaoDetailRow>(r);
}

export async function saveSimulacao(body: {
  nome_lote: string;
  dias_confinamento: number;
  peso_entrada_kg: number;
  gmd_projetado: number;
  cms_projetado: number;
  custo_diaria: number;
  params_json: string;
}): Promise<{ id: number }> {
  const r = await fetch(apiUrl('/api/simulacoes'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(await authHeader()) },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(await readErrorBody(r));
  return parseJsonResponse<{ id: number }>(r);
}

export async function deleteSimulacao(id: number): Promise<void> {
  const r = await fetch(apiUrl(`/api/simulacoes/${id}`), {
    method: 'DELETE',
    headers: await authHeader(),
  });
  if (!r.ok && r.status !== 204) throw new Error(await readErrorBody(r));
}
