import { useState, type FormEvent } from 'react';
import { Beef, Loader2, Lock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export function LoginPage() {
  const { signIn, configured } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await signIn(email, password);
    } catch (err: unknown) {
      const code = err && typeof err === 'object' && 'code' in err ? String((err as { code: string }).code) : '';
      const msg = err instanceof Error ? err.message : '';
      const low = msg.toLowerCase();
      if (low.includes('signinwithpassword') && low.includes('blocked')) {
        setError(
          'O login com e-mail e senha está bloqueado no projeto (Google Cloud / Firebase). ' +
            '1) Firebase Console → Authentication → Sign-in method → ative "E-mail/senha". ' +
            '2) Google Cloud Console → APIs e serviços → Credenciais → abra a chave de API do app Web e, em "Restrições de API", inclua "Identity Toolkit API" ou use "Não restringir chave" só para testar. ' +
            '3) Confira se o VITE_FIREBASE_API_KEY no .env é do mesmo projeto Firebase.'
        );
      } else if (msg.includes('identity-toolkit-api-has-not-been-used')) {
        setError(
          'A API Identity Toolkit ainda não está ativada no Google Cloud (necessária para o login Firebase). ' +
            'No Google Cloud Console → APIs e serviços → Biblioteca, procure por "Identity Toolkit API" e clique em Ativar. ' +
            'Ou use o link que aparece na mensagem técnica do navegador. Aguarde alguns minutos e tente de novo.'
        );
      } else if (code === 'auth/invalid-credential' || code === 'auth/wrong-password' || code === 'auth/user-not-found') {
        setError('E-mail ou senha incorretos.');
      } else if (code === 'auth/too-many-requests') {
        setError('Muitas tentativas. Tente mais tarde.');
      } else if (code === 'auth/user-disabled') {
        setError('Esta conta foi desativada.');
      } else {
        setError(msg || 'Não foi possível entrar.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (!configured) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-lg border border-slate-200 p-8">
          <div className="flex items-center gap-3 mb-4">
            <Beef className="text-orange-600" size={32} />
            <h1 className="text-xl font-bold text-slate-900">Login</h1>
          </div>
          <p className="text-sm text-slate-600 mb-4">
            Configure as variáveis <code className="bg-slate-100 px-1 rounded text-xs">VITE_FIREBASE_*</code> no
            arquivo <code className="bg-slate-100 px-1 rounded text-xs">.env</code> e faça um novo build. Use as
            chaves do projeto no Firebase Console → Configurações do projeto → Seus apps → SDK da Web.
          </p>
          <ul className="text-xs text-slate-500 list-disc pl-5 space-y-1">
            <li>VITE_FIREBASE_API_KEY</li>
            <li>VITE_FIREBASE_AUTH_DOMAIN</li>
            <li>VITE_FIREBASE_PROJECT_ID</li>
            <li>
              Opcional (mesmo snippet do Console, com prefixo{' '}
              <code className="bg-slate-100 px-0.5 rounded">VITE_</code>): VITE_FIREBASE_STORAGE_BUCKET,
              VITE_FIREBASE_MESSAGING_SENDER_ID, VITE_FIREBASE_APP_ID
            </li>
          </ul>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-100 to-slate-200 flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl border border-slate-200/80 overflow-hidden">
        <div className="bg-slate-900 text-white px-8 py-10 text-center">
          <Beef className="mx-auto mb-3 text-orange-400" size={40} />
          <h1 className="text-2xl font-bold tracking-tight">calculadora de arrobas</h1>
          <p className="text-slate-300 text-sm mt-2">(Seja bem vindos)</p>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-5">
          <div className="flex items-center gap-2 text-slate-700 font-medium text-sm">
            <Lock size={16} className="text-orange-600" />
            Entrar
          </div>
          {error && (
            <p className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{error}</p>
          )}
          <div className="space-y-1">
            <label htmlFor="login-email" className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              E-mail
            </label>
            <input
              id="login-email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500"
              placeholder="seu@email.com"
            />
          </div>
          <div className="space-y-1">
            <label htmlFor="login-password" className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Senha
            </label>
            <input
              id="login-password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="w-full flex items-center justify-center gap-2 bg-orange-600 hover:bg-orange-700 disabled:opacity-60 text-white font-semibold py-3 rounded-lg transition-colors"
          >
            {submitting ? <Loader2 className="animate-spin" size={20} /> : null}
            {submitting ? 'Entrando…' : 'Entrar'}
          </button>
          <p className="text-[11px] text-slate-400 text-center leading-relaxed">Acesso restrito</p>
        </form>
      </div>
    </div>
  );
}
