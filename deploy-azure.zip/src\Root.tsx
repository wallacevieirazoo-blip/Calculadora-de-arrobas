import { Loader2 } from 'lucide-react';
import App from './App.tsx';
import { LoginPage } from './components/LoginPage.tsx';
import { useAuth } from './contexts/AuthContext.tsx';

export default function Root() {
  const { user, loading, configured } = useAuth();

  if (loading && configured) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-3 text-slate-600">
        <Loader2 className="animate-spin text-orange-600" size={32} />
        <p className="text-sm">Verificando sessão…</p>
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  return <App />;
}
